kill @e[type=minecraft:item_display, tag=jbt.tape_selection]
