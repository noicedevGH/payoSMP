execute in minecraft:overworld run function jbt.void_bundle:save with storage jbt:temp bundle
$item modify entity @s $(slot) {"function":"minecraft:set_components","components":{"minecraft:bundle_contents":[]}}
playsound minecraft:entity.puffer_fish.blow_up player @a ~ ~ ~ 0.4 1
playsound minecraft:entity.illusioner.mirror_move player @a ~ ~ ~ 0.5 1.4
