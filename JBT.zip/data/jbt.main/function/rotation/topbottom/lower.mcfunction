$return run setblock ~ ~ ~ $(block)[type=bottom] destroy
