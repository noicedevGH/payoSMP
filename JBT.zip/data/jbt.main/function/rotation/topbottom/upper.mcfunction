$return run setblock ~ ~ ~ $(block)[type=top] destroy
