playsound minecraft:block.lava.extinguish player @a ~ ~ ~ 1 2
playsound minecraft:entity.illusioner.mirror_move player @a ~ ~ ~ 0.4 1.4
particle minecraft:smoke ~ ~0.4 ~ 0.3 0.3 0.3 0.01 20 force
function jbt.void_bucket:swing
execute if block ~ ~ ~ minecraft:lava run playsound minecraft:item.bucket.fill_lava player @a ~ ~ ~ 1 1
execute if block ~ ~ ~ minecraft:lava run return run setblock ~ ~ ~ minecraft:air replace
execute if block ~ ~ ~ minecraft:water run playsound minecraft:item.bucket.fill player @a ~ ~ ~ 1 1
execute if block ~ ~ ~ minecraft:water run return run setblock ~ ~ ~ minecraft:air replace
execute if block ~ ~ ~ minecraft:powder_snow run playsound minecraft:item.bucket.fill_powder_snow player @a ~ ~ ~ 1 1
execute if block ~ ~ ~ minecraft:powder_snow run return run setblock ~ ~ ~ minecraft:air replace
execute if block ~ ~ ~ minecraft:lava_cauldron run playsound minecraft:item.bucket.fill_lava player @a ~ ~ ~ 1 1
execute if block ~ ~ ~ minecraft:lava_cauldron run return run setblock ~ ~ ~ minecraft:cauldron replace
execute if block ~ ~ ~ minecraft:water_cauldron run playsound minecraft:item.bucket.fill player @a ~ ~ ~ 1 1
execute if block ~ ~ ~ minecraft:water_cauldron run return run setblock ~ ~ ~ minecraft:cauldron replace
execute if block ~ ~ ~ minecraft:powder_snow_cauldron run playsound minecraft:item.bucket.fill_powder_snow player @a ~ ~ ~ 1 1
execute if block ~ ~ ~ minecraft:powder_snow_cauldron run setblock ~ ~ ~ minecraft:cauldron replace
