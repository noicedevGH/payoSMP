$summon minecraft:experience_orb ~ ~ ~ {Value:0,Motion:[$(orbx),$(orby),$(orbz)]}
