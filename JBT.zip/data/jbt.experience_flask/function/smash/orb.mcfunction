$summon minecraft:experience_orb ~ ~ ~ {Value:$(value),Motion:[$(orbx),$(orby),$(orbz)]}
