execute unless entity @s as @e[tag=jbt.flask_fix] run function jbt.experience_flask:potion/fix
execute store result entity @s Air short 1 run time query gametime
tag @s remove jbt.flask_fix
