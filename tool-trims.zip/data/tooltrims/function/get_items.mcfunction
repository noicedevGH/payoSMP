scoreboard players set @s tooltrims.amount 64
loot give @s loot tooltrims:give_linear_templates
loot give @s loot tooltrims:give_tracks_templates
loot give @s loot tooltrims:give_charge_templates
loot give @s loot tooltrims:give_frost_templates