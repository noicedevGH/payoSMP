$summon firework_rocket ~ ~1.5 ~ {LifeTime:0,FireworksItem:{id:"minecraft:firework_rocket",count:1,components:{"minecraft:fireworks":{explosions:[{shape:"$(shape)",has_twinkle:$(twinkle),has_trail:$(trail),colors:[I;$(colors_1)],fade_colors:[I;$(fade_colors_1)]}]}}}}

kill @s